let leaderboard = [];
let previousScores = [];
let recentScore = null;
let currentUser = null; 
let activityLog = {}; 
let personalBest = {}; 
let recentActivities = []; // For live updates

// Login functionality
document.getElementById("login-button").addEventListener("click", function () {
    const loginPasswordInput = document.getElementById("login-password-input").value;
    const errorMessage = document.getElementById("login-error-message");

    if (loginPasswordInput === "6902") {
        errorMessage.textContent = "";
        document.getElementById("password-panel").classList.add("hidden");
        document.getElementById("menu-panel").classList.remove("hidden");
    } else {
        errorMessage.textContent = "Incorrect password. Please try again.";
    }
});

// Menu navigation
document.getElementById("signup-button").addEventListener("click", function () {
    document.getElementById("menu-panel").classList.add("hidden");
    document.getElementById("signup-panel").classList.remove("hidden");
});

document.getElementById("existing-login-button").addEventListener("click", function () {
    document.getElementById("menu-panel").classList.add("hidden");
    document.getElementById("login-panel").classList.remove("hidden");
});

// Handle Sign-Up
document.getElementById("submit-signup-button").addEventListener("click", function () {
    const nameInput = document.getElementById("name-input").value;
    const passwordInput = document.getElementById("password-input").value;
    const confirmPasswordInput = document.getElementById("confirm-password-input").value;
    const errorMessage = document.getElementById("signup-error-message");

    if (nameInput && passwordInput === confirmPasswordInput && passwordInput !== "") {
        if (leaderboard.find(user => user.name === nameInput)) {
            errorMessage.textContent = "This name is already taken. Please choose another.";
            return;
        }
        leaderboard.push({ name: nameInput, points: 0, password: passwordInput });
        activityLog[nameInput] = []; // Initialize activity log for new user
        personalBest[nameInput] = {}; // Initialize personal bests for tracked activities

        errorMessage.textContent = "";
        document.getElementById("signup-panel").classList.add("hidden");
        document.getElementById("main-panel").classList.remove("hidden");
        currentUser = leaderboard[leaderboard.length - 1]; // Set current user to last added
        updateLeaderboard();
        document.getElementById("name-input").value = ""; // Clear input field
        document.getElementById("password-input").value = ""; // Clear password field
        document.getElementById("confirm-password-input").value = ""; // Clear confirm password field
    } else {
        errorMessage.textContent = "Make sure your passwords match and are not empty.";
    }
});

// Handle Login
document.getElementById("submit-login-button").addEventListener("click", function () {
    const nameInput = document.getElementById("login-name-input").value;
    const passwordInput = document.getElementById("login-user-password-input").value;

    const errorMessage = document.getElementById("user-login-error-message");
    const user = leaderboard.find(user => user.name === nameInput && user.password === passwordInput);

    if (user) {
        errorMessage.textContent = "";
        currentUser = user; // Set current user
        document.getElementById("login-panel").classList.add("hidden");
        document.getElementById("main-panel").classList.remove("hidden");
        updateLeaderboard();
    } else {
        errorMessage.textContent = "Incorrect name or password. Please try again.";
    }
});

// Handle Point Menu Toggle
document.getElementById("add-points-button").addEventListener("click", function () {
    document.getElementById("main-panel").classList.add("hidden");
    document.getElementById("points-menu").classList.remove("hidden");
});

// Confirm Points and Activity
document.getElementById("confirm-points-button").addEventListener("click", function () {
    const pointsInput = parseInt(document.getElementById("points-input").value);
    const activityInput = document.getElementById("activity-select").value;

    if (!isNaN(pointsInput) && activityInput) {
        recentScore = { user: currentUser.name, points: pointsInput, activity: activityInput, timestamp: new Date() }; 
        previousScores.push(currentUser.points); 
        currentUser.points += pointsInput; 

        // Update personal best for the specific activity
        if (!personalBest[currentUser.name][activityInput]) {
            personalBest[currentUser.name][activityInput] = 0; // Initialize if not present
        }
        personalBest[currentUser.name][activityInput] = Math.max(personalBest[currentUser.name][activityInput], pointsInput); 

        activityLog[currentUser.name].push({ activity: activityInput, points: pointsInput, timestamp: recentScore.timestamp }); 
        recentActivities.unshift(recentScore);
        updateLiveUpdates(); // Update live updates display

        updateLeaderboard();
        document.getElementById("points-input").value = ""; 
        document.getElementById("activity-select").value = ""; 
    }
});

// Undo functionality in Points Menu
document.getElementById("undo-button").addEventListener("click", function () {
    if (recentScore) {
        const respectiveUser = leaderboard.find(u => u.name === recentScore.user);
        respectiveUser.points = previousScores.pop() || 0; 
        recentScore = null; 
        updateLeaderboard();
    }
});

// Handle Rules Page
document.getElementById("rules-button").addEventListener("click", function () {
    document.getElementById("main-panel").classList.add("hidden");
    document.getElementById("rules-panel").classList.remove("hidden");
});

// Handle Back to Points Page
document.getElementById("back-button").addEventListener("click", function () {
    document.getElementById("rules-panel").classList.add("hidden");
    document.getElementById("main-panel").classList.remove("hidden");
});

// Handle back to home functionality
document.getElementById("home-button").addEventListener("click", function () {
    document.getElementById("main-panel").classList.add("hidden");
    document.getElementById("signup-panel").classList.add("hidden");
    document.getElementById("login-panel").classList.add("hidden");
    document.getElementById("menu-panel").classList.add("hidden");
    document.getElementById("password-panel").classList.remove("hidden");
});

// Add home button functionality for signup and login
document.getElementById("signup-home-button").addEventListener("click", function () {
    document.getElementById("signup-panel").classList.add("hidden");
    document.getElementById("menu-panel").classList.remove("hidden");
});

document.getElementById("login-home-button").addEventListener("click", function () {
    document.getElementById("login-panel").classList.add("hidden");
    document.getElementById("menu-panel").classList.remove("hidden");
});

// Add home button functionality for points menu
document.getElementById("points-menu-home-button").addEventListener("click", function () {
    document.getElementById("points-menu").classList.add("hidden");
    document.getElementById("main-panel").classList.remove("hidden");
});

// Handle User Detail View
document.getElementById("leaderboard-list").addEventListener("click", function (e) {
    const userName = e.target.textContent.split(":")[0].trim(); 
    const userActivities = activityLog[userName] || [];
    document.getElementById("user-detail-name").textContent = userName;

    const userDetailList = document.getElementById("user-detail-list");
    userDetailList.innerHTML = ""; 

    userActivities.forEach(activity => {
        const listItem = document.createElement("li");
        listItem.textContent = `${activity.activity}: ${activity.points} Points`;
        
        const timeDiff = Math.floor((Date.now() - new Date(activity.timestamp).getTime()) / 1000);
        listItem.textContent += ` (${formatTimeSince(timeDiff)})`; 
        
        userDetailList.appendChild(listItem);
    });

    // Update Personal Bests Display
    updatePersonalBests(); // Update personal bests when viewing user details
    document.getElementById("main-panel").classList.add("hidden");
    document.getElementById("user-detail-panel").classList.remove("hidden");
});

// Add back to home functionality for user detail panel
document.getElementById("user-detail-home-button").addEventListener("click", function () {
    document.getElementById("user-detail-panel").classList.add("hidden");
    document.getElementById("main-panel").classList.remove("hidden");
    showLeaderboard(); // Show leaderboard with live updates again
});

// Update Personal Bests Display
function updatePersonalBests() {
    const personalBestList = document.getElementById("personal-best-list");
    personalBestList.innerHTML = ""; // Clear current list
    const activities = ["run", "bike", "walk", "erg"]; // Define activities to check

    activities.forEach(activity => {
        const listItem = document.createElement("li");
        listItem.textContent = `${activity.charAt(0).toUpperCase() + activity.slice(1)}: ${personalBest[currentUser.name] ? personalBest[currentUser.name][activity] || 0 : 0} Points`;
        personalBestList.appendChild(listItem);
    });
}

// Update Live Updates
function updateLiveUpdates() {
    const liveUpdatesList = document.getElementById("live-updates-list");
    liveUpdatesList.innerHTML = ""; 

    recentActivities.slice(0, 5).forEach(entry => {
        const listItem = document.createElement("li");
        const timeDiff = Math.floor((Date.now() - new Date(entry.timestamp).getTime()) / 1000);
        listItem.textContent = `${entry.user} completed ${entry.activity.charAt(0).toUpperCase() + entry.activity.slice(1)} (${formatTimeSince(timeDiff)})`;
        liveUpdatesList.appendChild(listItem);
    });
}

// Format time since activity in a readable way
function formatTimeSince(seconds) {
    if (seconds < 60) return `${seconds} seconds ago`;
    else if (seconds < 3600) return `${Math.floor(seconds / 60)} minutes ago`;
    else if (seconds < 86400) return `${Math.floor(seconds / 3600)} hours ago`;
    else if (seconds < 2592000) return `${Math.floor(seconds / 86400)} days ago`;
    else return "30+ days ago"; 
}

// Update Leaderboard
function updateLeaderboard() {
    leaderboard.sort((a, b) => b.points - a.points); // Sort leaderboard based on points
    const leaderboardList = document.getElementById("leaderboard-list");
    leaderboardList.innerHTML = ""; 

    leaderboard.slice(0, 10).forEach((entry) => { // Only show top 10
        const listItem = document.createElement("li");
        listItem.textContent = `${entry.name}: ${entry.points} Points`;
        leaderboardList.appendChild(listItem);
    });
}

// Custom function to show leaderboard and handle live updates
function showLeaderboard() {
    document.getElementById("main-panel").classList.add("hidden");
    document.getElementById("leaderboard").classList.remove("hidden");
    document.getElementById("live-updates-panel").classList.remove("hidden"); // Show live updates when leaderboard is shown
}