const correctPassword = '6902';
let currentUser = '';
let users = {};
let chatLog = [];

function switchPanel(showId) {
  document.querySelectorAll('.panel').forEach(p => p.classList.add('hidden'));
  document.getElementById(showId).classList.remove('hidden');
}

document.getElementById("login-button").onclick = () => {
  const pass = document.getElementById("login-password-input").value;
  if (pass === correctPassword) switchPanel("menu-panel");
  else document.getElementById("login-error-message").textContent = "Incorrect password.";
};

document.getElementById("signup-button").onclick = () => switchPanel("signup-panel");
document.getElementById("existing-login-button").onclick = () => switchPanel("login-panel");

document.getElementById("submit-signup-button").onclick = () => {
  const name = document.getElementById("name-input").value;
  const pass = document.getElementById("password-input").value;
  const confirm = document.getElementById("confirm-password-input").value;
  if (name && pass === confirm) {
    users[name] = { pass, workouts: [], totals: { Run: 0, Bike: 0, Erg: 0 }, highs: { Run: 0, Bike: 0, Erg: 0 } };
    currentUser = name;
    updateLeaderboard();
    switchPanel("main-panel");
  } else {
    document.getElementById("signup-error-message").textContent = "Invalid signup info.";
  }
};

document.getElementById("submit-login-button").onclick = () => {
  const name = document.getElementById("login-name-input").value;
  const pass = document.getElementById("login-user-password-input").value;
  if (users[name] && users[name].pass === pass) {
    currentUser = name;
    updateLeaderboard();
    switchPanel("main-panel");
  } else {
    document.getElementById("user-login-error-message").textContent = "Invalid login.";
  }
};

document.getElementById("home-button").onclick = () => switchPanel("password-panel");
document.querySelectorAll(".back-home").forEach(btn => btn.onclick = () => switchPanel("password-panel"));
document.querySelectorAll(".back-to-leaderboard").forEach(btn => btn.onclick = () => switchPanel("main-panel"));

document.getElementById("rules-button").onclick = () => switchPanel("rules-panel");
document.getElementById("add-points-button").onclick = () => switchPanel("points-menu");
document.getElementById("chat-button").onclick = () => {
  renderChat();
  switchPanel("chat-panel");
};

document.getElementById("confirm-points-button").onclick = () => {
  const pts = parseInt(document.getElementById("points-input").value);
  const activity = document.getElementById("activity-select").value;
  const fileInput = document.getElementById("photo-upload");
  const file = fileInput.files[0];

  if (!pts || !activity || !file) return;

  const reader = new FileReader();
  reader.onload = function (e) {
    const photoURL = e.target.result;
    const time = Date.now();
    users[currentUser].workouts.unshift({ pts, activity, time });
    users[currentUser].totals[activity] += pts;
    if (pts > users[currentUser].highs[activity]) users[currentUser].highs[activity] = pts;

    chatLog.unshift({ user: currentUser, pts, activity, photo: photoURL, time });
    updateLeaderboard();

    document.getElementById("points-input").value = "";
    document.getElementById("photo-upload").value = "";
    switchPanel("main-panel");
  };
  reader.readAsDataURL(file);
};

document.getElementById("send-button").onclick = () => {
  const msg = document.getElementById("chat-input").value;
  if (msg) {
    chatLog.unshift({ user: currentUser, msg, time: Date.now() });
    document.getElementById("chat-input").value = "";
    renderChat();
  }
};

function updateLeaderboard() {
  const list = document.getElementById("leaderboard-list");
  list.innerHTML = '';
  Object.entries(users).sort((a, b) => {
    const ta = Object.values(a[1].totals).reduce((x, y) => x + y, 0);
    const tb = Object.values(b[1].totals).reduce((x, y) => x + y, 0);
    return tb - ta;
  }).forEach(([name, data]) => {
    const total = Object.values(data.totals).reduce((x, y) => x + y, 0);
    const li = document.createElement("li");
    li.textContent = `${name} - ${total} pts`;
    li.onclick = () => showUserDetail(name);
    list.appendChild(li);
  });
}

function showUserDetail(name) {
  const user = users[name];
  const total = Object.values(user.totals).reduce((x, y) => x + y, 0);
  document.getElementById("user-detail-name").textContent = name;
  document.getElementById("user-total-points").textContent = `${total} Total Points`;

  const top = Object.entries(user.highs).sort((a, b) => b[1] - a[1]);
  const totalList = Object.entries(user.totals).sort((a, b) => b[1] - a[1]);

  document.getElementById("highest-scores-list").innerHTML = top.map(([k, v]) => `<li>${k}: ${v} pts</li>`).join("");
  document.getElementById("total-points-list").innerHTML = totalList.map(([k, v]) => `<li>${k}: ${v} pts</li>`).join("");

  const now = Date.now();
  document.getElementById("recent-activities-list").innerHTML = user.workouts.map(w => {
    let ago = Math.floor((now - w.time) / 1000);
    const units = ["s", "m", "h", "d"];
    const times = [60, 60, 24];
    let i = 0;
    while (i < times.length && ago >= times[i]) {
      ago = Math.floor(ago / times[i]);
      i++;
    }
    const disp = i < units.length ? `${ago}${units[i]}` : "30+ Days";
    return `<li>${w.activity} - ${w.pts} pts (${disp} ago)</li>`;
  }).join("");

  switchPanel("user-detail-panel");
}

function renderChat() {
  const chat = document.getElementById("chat-messages");
  chat.innerHTML = chatLog.map(c => {
    if (c.msg) return `<li><strong>${c.user}:</strong> ${c.msg}</li>`;
    return `<li><img src="${c.photo}" /><br><strong>${c.user}:</strong> did ${c.pts} points (${c.activity})</li>`;
  }).join("");
}
